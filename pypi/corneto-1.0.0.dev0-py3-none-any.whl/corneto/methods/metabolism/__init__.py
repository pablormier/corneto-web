from corneto.methods.metabolism._utils import evaluate_gpr_rules
