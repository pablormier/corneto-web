
# THIS FILE IS GENERATED FROM CVXPY SETUP.PY
short_version = '1.4.3'
version = '1.4.3'
full_version = '1.4.3'
git_revision = '4d4df4d'
commit_count = '4d4df4d'
release = True
if not release:
    version = full_version
